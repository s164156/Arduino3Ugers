package xyz.arpith.blearduino;
import java.io.Serializable;

/**
 * Created by Home on 13/06/2018.
 */


public class user implements Serializable{
    private String name = "";

    public user(){
        super();
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getName(){
        return name;
    }
}