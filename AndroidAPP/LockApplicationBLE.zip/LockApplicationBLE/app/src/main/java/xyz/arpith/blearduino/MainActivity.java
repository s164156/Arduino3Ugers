package xyz.arpith.blearduino;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;


import android.os.Bundle;
import android.widget.Toast;

import java.io.Serializable;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.util.Calendar;

public class MainActivity extends Activity implements Serializable {
    Button loginB;
    EditText username,password;
    TextView textViewDate,textViewTime, errormsg;

    user object = new user();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        requestWindowFeature(Window.FEATURE_NO_TITLE);
        //Full screen is set for the Window
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_main);

        Calendar calendar = Calendar.getInstance();
        String currentDate = DateFormat.getDateInstance().format(calendar.getTime());

        Timestamp tsLong = new Timestamp(System.currentTimeMillis());
        String timeStamp = tsLong.toString();

        textViewDate = (TextView) findViewById(R.id.Date);
        textViewTime = (TextView) findViewById(R.id.Time);
        errormsg = (TextView) findViewById(R.id.errormsg);

        loginB = (Button) findViewById(R.id.loginbutton);

        username = (EditText) findViewById(R.id.username);
        password = (EditText) findViewById(R.id.password);

        textViewDate.setText(currentDate);
        textViewTime.setText(timeStamp.substring(10, 16));

        final Toast toast = Toast.makeText(this, "Wrong username or password", Toast.LENGTH_SHORT);


        loginB.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String getName = username.getText().toString();
                String getPassword = password.getText().toString();
                if ((getName.equals("m")) && (getPassword.equals("m"))){
                    Intent intent = new Intent(MainActivity.this, homePageActivity.class);
                    intent.putExtra("MyClass", "M");
                    startActivity(intent);
                } else if ((getName.equals("sebastian")) && (getPassword.equals("freezepolice1"))) {
                    Intent intent = new Intent(MainActivity.this, homePageActivity.class);
                    object.setName(getName);
                    intent.putExtra("MyClass", "X");
                    startActivity(intent);
                } else {
                    toast.show();
                    errormsg.setText("Wrong username or password");
                }
            }
        });
    }
}
