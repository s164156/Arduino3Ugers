package xyz.arpith.blearduino;

import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;

import java.io.Serializable;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.util.Calendar;

public class homePageActivity extends Activity implements Serializable {
    private Button buttonBlue,buttonLock,buttonLed,buttonLog;
    private static final int REQUEST_ENABLE_BT = 1;
    private BluetoothAdapter mBluetoothAdapter;
    TextView textViewDate, textViewTime;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);

        requestWindowFeature(Window.FEATURE_NO_TITLE);
        //Full screen is set for the Window
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_home_page);

        Calendar calendar = Calendar.getInstance();
        String currentDate = DateFormat.getDateInstance().format(calendar.getTime());

        Timestamp tsLong = new Timestamp(System.currentTimeMillis());
        String timeStamp = tsLong.toString();

        textViewDate = (TextView) findViewById(R.id.Date);
        textViewTime = (TextView) findViewById(R.id.Time);


        // Ensures Bluetooth is available on the device and it is enabled. If not,
        // displays a dialog requesting user permission to enable Bluetooth.

        buttonBlue = (Button) findViewById(R.id.buttonBluetooth);
        buttonLog = (Button) findViewById(R.id.buttonLog);

        final String username = getIntent().getSerializableExtra("MyClass").toString(); //receive the address of the bluetooth device

        textViewDate.setText(currentDate);
        textViewTime.setText(timeStamp.substring(10, 16));


        buttonBlue.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(homePageActivity.this, DeviceScanActivity .class);
                intent.putExtra("MyClass", username);
                startActivity(intent);
            }
        });

        buttonLog.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(homePageActivity.this, MainActivity .class);
                startActivity(intent);
            }
        });
    }
}